void oracle_sqrt(
  int Pre_a, int a, 
  int pathcrawler__retres__sqrt)
{
  int i = pathcrawler__retres__sqrt;

  /* A remplacer par un vrai verdict */
  pathcrawler_verdict_unknown();
  
  return;
  
}
